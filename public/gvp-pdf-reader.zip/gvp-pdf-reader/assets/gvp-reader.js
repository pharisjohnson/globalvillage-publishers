/**
 * GVP Read-Only PDF Reader — vanilla JS.
 *
 * Renders each PDF page to a <canvas> (so the document is read on-screen and
 * cannot be downloaded from the page) and lays the pages out as one continuous
 * scroll. Pages render lazily as they scroll into view. PDF.js is loaded from
 * the jsDelivr CDN only when a `.gvp-reader` container is present.
 *
 * The same read-only viewer that powers the Teachers' Image archive at
 * globalvillagepublishers.co.ke, packaged for WordPress.
 */
(function () {
	'use strict';

	var PDFJS_VERSION = '6.5.438';
	var CDN = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@' + PDFJS_VERSION + '/build/';
	var MAX_SCALE = 2.5;
	var TRACK_THRESHOLD = 150;

	var ICONS = {
		up: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none"><path d="M12 19V5m0 0l-6 6m6-6l6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		share: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none"><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M16 6l-4-4-4 4M12 2v13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		wa: '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="#25D366" d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21 5.46 0 9.91-4.45 9.91-9.91C21.95 6.45 17.5 2 12.04 2zm0 18.15c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.24 8.24 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24 4.54 0 8.24 3.7 8.24 8.24 0 4.55-3.7 8.24-8.24 8.24z"/></svg>',
		fb: '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="#1877F2" d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.09 10.13 24v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.7 4.53-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.51c-1.49 0-1.95.93-1.95 1.89v2.26h3.32l-.53 3.49h-2.79V24C19.61 23.09 24 18.1 24 12.07z"/></svg>',
		x: '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="#111" d="M18.9 1.15h3.68l-8.04 9.19L24 22.85h-7.41l-5.8-7.58-6.64 7.58H.47l8.6-9.83L0 1.15h7.6l5.24 6.93 6.06-6.93z"/></svg>',
		link: '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="#EC5C23" d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c-.01-.82-.12-1.64-.36-2.42l.43-.43a3.004 3.004 0 0 0 0-4.24 3.004 3.004 0 0 0-4.24 0L10.59 6.7a3.004 3.004 0 0 0 0 4.24zM5.34 15.34a5.003 5.003 0 0 0 0 7.07 5.003 5.003 0 0 0 7.07 0l3.54-3.54a5.003 5.003 0 0 0 0-7.07c.39.39.39 1.03 0 1.42-.39.39-1.03.39-1.42 0a3.004 3.004 0 0 0-4.24 0L7.28 16.7a3.004 3.004 0 0 0 0 4.24 3.004 3.004 0 0 0 4.24 0l.43-.43c.24.78.35 1.6.36 2.42l-1.49 1.49a5.003 5.003 0 0 1-7.07 0z"/></svg>'
	};

	function ready(fn) {
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', fn);
		} else {
			fn();
		}
	}

	ready(function () {
		var containers = document.querySelectorAll('.gvp-reader');
		if (!containers.length) {
			return;
		}
		init(Array.prototype.slice.call(containers));
	});

	async function init(containers) {
		var pdfjs;
		try {
			pdfjs = await import(CDN + 'pdf.min.mjs');
		} catch (err) {
			containers.forEach(function (c) {
				showState(c, 'The PDF viewer could not be loaded.', 'error');
			});
			return;
		}

		pdfjs.GlobalWorkerOptions.workerSrc = CDN + 'pdf.worker.min.mjs';

		containers.forEach(function (container) {
			try {
				new Reader(container, pdfjs).start();
			} catch (err) {
				showState(container, 'The PDF viewer could not be started.', 'error');
			}
		});
	}

	function showState(container, message, kind) {
		var el = document.createElement('div');
		el.className = 'gvp-state' + (kind === 'error' ? ' gvp-state-error' : '');
		var spinner = document.createElement('div');
		spinner.className = 'gvp-spinner';
		var text = document.createElement('span');
		text.textContent = message;
		el.appendChild(spinner);
		el.appendChild(text);
		container.appendChild(el);
	}

	function readConfig(container) {
		var cfg = {};
		try {
			cfg = JSON.parse(container.getAttribute('data-config') || '{}');
		} catch (e) {
			cfg = {};
		}
		return {
			src: cfg.src || '',
			title: cfg.title || 'Publication',
			share: cfg.share !== 0,
			top: cfg.top !== 0
		};
	}

	function Reader(container, pdfjs) {
		this.container = container;
		this.pdfjs = pdfjs;
		this.cfg = readConfig(container);
		this.doc = null;
		this.numPages = 0;
		this.aspects = [];
		this.currentPage = 1;
		this.pagesEl = null;
		this.topBtn = null;
		this.sharePopover = null;
		this.shareBtn = null;
		this._observer = null;
		this._scrollHandler = null;
	}

	Reader.prototype.start = function () {
		var self = this;
		this.buildShell();
		this.pdfjs.getDocument({ url: this.cfg.src }).promise.then(function (doc) {
			self.doc = doc;
			self.numPages = doc.numPages;
			self.countEl.textContent = doc.numPages + ' pages';
			return self.loadAspects();
		}).then(function () {
			self.buildPages();
			self.wire();
			self.applyDeepLink();
		}).catch(function (err) {
			self.showError(err && err.message ? err.message : 'Could not load the document.');
		});
	};

	Reader.prototype.buildShell = function () {
		this.container.setAttribute('data-gvp-loaded', '1');
		this.container.innerHTML = '';

		var toolbar = document.createElement('div');
		toolbar.className = 'gvp-toolbar';

		var title = document.createElement('span');
		title.className = 'gvp-title';
		title.textContent = this.cfg.title;
		var count = document.createElement('span');
		count.className = 'gvp-count';
		count.textContent = '';

		toolbar.appendChild(title);
		toolbar.appendChild(count);

		var pages = document.createElement('div');
		pages.className = 'gvp-pages';

		var state = document.createElement('div');
		state.className = 'gvp-state';
		var spinner = document.createElement('div');
		spinner.className = 'gvp-spinner';
		var stateText = document.createElement('span');
		stateText.textContent = 'Preparing publication…';
		state.appendChild(spinner);
		state.appendChild(stateText);

		this.container.appendChild(toolbar);
		this.container.appendChild(pages);
		this.container.appendChild(state);

		this.pagesEl = pages;
		this.countEl = count;
		this.stateEl = state;

		this.buildActions();
	};

	Reader.prototype.buildActions = function () {
		var actions = document.createElement('div');
		actions.className = 'gvp-actions';

		if (this.cfg.share) {
			var popover = document.createElement('div');
			popover.className = 'gvp-popover';
			popover.hidden = true;

			var makeLink = function (icon, label) {
				var a = document.createElement('a');
				a.className = 'gvp-share-option';
				a.innerHTML = icon;
				a.href = '#';
				a.target = '_blank';
				a.rel = 'noopener noreferrer';
				var t = document.createElement('span');
				t.textContent = label;
				a.appendChild(t);
				return a;
			};

			var self = this;
			this.waOption = makeLink(ICONS.wa, 'WhatsApp');
			this.fbOption = makeLink(ICONS.fb, 'Facebook');
			this.xOption = makeLink(ICONS.x, 'X (Twitter)');

			this.copyOption = document.createElement('button');
			this.copyOption.type = 'button';
			this.copyOption.className = 'gvp-share-option';
			this.copyOption.innerHTML = ICONS.link;
			var copyLabel = document.createElement('span');
			copyLabel.textContent = 'Copy link';
			this.copyOption.appendChild(copyLabel);
			this.copyOption.addEventListener('click', function () {
				self.copyLink();
			});

			popover.appendChild(this.waOption);
			popover.appendChild(this.fbOption);
			popover.appendChild(this.xOption);
			popover.appendChild(this.copyOption);
			this.sharePopover = popover;

			var shareBtn = document.createElement('button');
			shareBtn.type = 'button';
			shareBtn.className = 'gvp-fab gvp-fab-share';
			shareBtn.setAttribute('aria-label', 'Share this page');
			shareBtn.innerHTML = ICONS.share;
			var shareLabel = document.createElement('span');
			shareLabel.textContent = 'Share';
			shareBtn.appendChild(shareLabel);
			shareBtn.addEventListener('click', function (e) {
				e.stopPropagation();
				self.toggleShare();
			});
			this.shareBtn = shareBtn;

			actions.appendChild(popover);
			actions.appendChild(shareBtn);
		}

		if (this.cfg.top) {
			var topBtn = document.createElement('button');
			topBtn.type = 'button';
			topBtn.className = 'gvp-fab gvp-fab-top';
			topBtn.setAttribute('aria-label', 'Back to top');
			topBtn.innerHTML = ICONS.up;
			topBtn.addEventListener('click', function () {
				window.scrollTo({ top: 0, behavior: 'smooth' });
			});
			this.topBtn = topBtn;
			actions.appendChild(topBtn);
		}

		this.container.appendChild(actions);
	};

	Reader.prototype.loadAspects = function () {
		var self = this;
		var chain = Promise.resolve();
		for (var n = 1; n <= this.numPages; n++) {
			chain = chain.then((function (pageNumber) {
				return function () {
					return self.doc.getPage(pageNumber).then(function (page) {
						var vp = page.getViewport({ scale: 1 });
						self.aspects[pageNumber - 1] = vp.height > 0 ? vp.width / vp.height : 0.707;
					}).catch(function () {
						self.aspects[pageNumber - 1] = 0.707;
					});
				};
			})(n));
		}
		return chain;
	};

	Reader.prototype.buildPages = function () {
		this.stateEl.remove();

		for (var n = 1; n <= this.numPages; n++) {
			var pageEl = document.createElement('div');
			pageEl.className = 'gvp-page';
			pageEl.setAttribute('data-page-number', String(n));
			pageEl.style.aspectRatio = String(this.aspects[n - 1] || 0.707);

			var surface = document.createElement('div');
			surface.className = 'gvp-page-surface';
			var canvas = document.createElement('canvas');
			canvas.className = 'gvp-page-canvas';
			var textLayer = document.createElement('div');
			textLayer.className = 'gvp-text-layer';
			surface.appendChild(canvas);
			surface.appendChild(textLayer);

			var status = document.createElement('div');
			status.className = 'gvp-page-status';
			var spinner = document.createElement('div');
			spinner.className = 'gvp-spinner';
			var statusText = document.createElement('span');
			statusText.textContent = 'Loading page ' + n + '…';
			status.appendChild(spinner);
			status.appendChild(statusText);

			pageEl.appendChild(surface);
			pageEl.appendChild(status);
			this.pagesEl.appendChild(pageEl);
		}
	};

	Reader.prototype.wire = function () {
		var self = this;
		var pages = this.pagesEl.querySelectorAll('.gvp-page');

		if ('IntersectionObserver' in window) {
			this._observer = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						var pageNumber = Number(entry.target.getAttribute('data-page-number'));
						self.renderPage(entry.target, pageNumber);
						self._observer.unobserve(entry.target);
					}
				});
			}, { rootMargin: '800px 0px' });
			pages.forEach(function (p) {
				self._observer.observe(p);
			});
		} else {
			pages.forEach(function (p) {
				self.renderPage(p, Number(p.getAttribute('data-page-number')));
			});
		}

		var onScroll = function () {
			self.updateCurrentPage();
			if (self.topBtn) {
				self.topBtn.classList.toggle('gvp-visible', window.scrollY > 600);
			}
		};
		this._scrollHandler = onScroll;
		window.addEventListener('scroll', onScroll, { passive: true });
		window.addEventListener('resize', onScroll, { passive: true });
		onScroll();

		document.addEventListener('click', function (e) {
			if (self.sharePopover && !self.sharePopover.hidden && !self.sharePopover.contains(e.target) && e.target !== self.shareBtn) {
				self.sharePopover.hidden = true;
			}
		});
	};

	Reader.prototype.renderPage = function (pageEl, pageNumber) {
		var self = this;
		if (pageEl._started) {
			return;
		}
		pageEl._started = true;

		var canvas = pageEl.querySelector('canvas');
		var surface = pageEl.querySelector('.gvp-page-surface');
		var textLayer = pageEl.querySelector('.gvp-text-layer');
		var status = pageEl.querySelector('.gvp-page-status');

		this.doc.getPage(pageNumber).then(function (page) {
			var base = page.getViewport({ scale: 1 });
			var containerWidth = pageEl.clientWidth || 820;
			var scale = Math.min(containerWidth / base.width, MAX_SCALE);
			var viewport = page.getViewport({ scale: scale });
			var ctx = canvas.getContext('2d');
			if (!ctx) {
				throw new Error('No 2d context');
			}

			var dpr = Math.min(window.devicePixelRatio || 1, 2);
			canvas.width = Math.floor(viewport.width * dpr);
			canvas.height = Math.floor(viewport.height * dpr);
			canvas.style.width = Math.floor(viewport.width) + 'px';
			canvas.style.height = Math.floor(viewport.height) + 'px';
			surface.style.width = Math.floor(viewport.width) + 'px';
			surface.style.height = Math.floor(viewport.height) + 'px';
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

			return page.render({ canvasContext: ctx, viewport: viewport }).promise.then(function () {
				if (self.pdfjs.TextLayer) {
					textLayer.style.setProperty('--total-scale-factor', String(scale));
					textLayer.style.setProperty('--scale-factor', String(scale));
					textLayer.style.setProperty('--scale-round-x', '1px');
					textLayer.style.setProperty('--scale-round-y', '1px');
					return page.getTextContent().then(function (textContent) {
						var layer = new self.pdfjs.TextLayer({
							textContentSource: textContent,
							container: textLayer,
							viewport: viewport
						});
						return layer.render();
					}).catch(function () {
						/* text layer is best-effort */
					});
				}
			}).then(function () {
				if (page.cleanup) {
					page.cleanup();
				}
				if (status && status.parentNode) {
					status.parentNode.removeChild(status);
				}
			});
		}).catch(function () {
			if (status) {
				var t = status.querySelector('span');
				if (t) {
					t.textContent = 'Failed to load page';
				}
			}
		});
	};

	Reader.prototype.updateCurrentPage = function () {
		var pages = this.pagesEl.querySelectorAll('[data-page-number]');
		if (!pages.length) {
			return;
		}
		var current = 1;
		for (var i = 0; i < pages.length; i++) {
			var el = pages[i];
			if (el.getBoundingClientRect().top <= TRACK_THRESHOLD) {
				current = Number(el.getAttribute('data-page-number'));
			}
		}
		this.currentPage = current;
	};

	Reader.prototype.shareUrl = function () {
		var base = window.location.origin + window.location.pathname;
		return base + '#gvp-page=' + this.currentPage;
	};

	Reader.prototype.toggleShare = function () {
		if (!this.sharePopover) {
			return;
		}
		var selection = '';
		try {
			selection = (window.getSelection() || '').toString().trim();
		} catch (e) {
			selection = '';
		}
		this._selection = selection;
		this.updateShareLinks();
		this.sharePopover.hidden = !this.sharePopover.hidden;
	};

	Reader.prototype.updateShareLinks = function () {
		if (!this.sharePopover) {
			return;
		}
		var url = this.shareUrl();
		var title = this.cfg.title + ' (page ' + this.currentPage + ')';
		var body = this._selection ? title + '\n\n“' + this._selection + '”' : title;

		this.waOption.href = 'https://wa.me/?text=' + encodeURIComponent(body + '\n' + url);
		this.fbOption.href = 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url);
		this.xOption.href = 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(body);
	};

	Reader.prototype.copyLink = function () {
		var url = this.shareUrl();
		var label = this.copyOption.querySelector('span');
		var done = function () {
			if (label) {
				label.textContent = 'Copied!';
			}
			setTimeout(function () {
				if (label) {
					label.textContent = 'Copy link';
				}
			}, 2000);
		};
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(url).then(done, done);
		} else {
			done();
		}
	};

	Reader.prototype.applyDeepLink = function () {
		var m = /[#&]gvp-page=(\d+)/.exec(window.location.hash);
		if (!m) {
			return;
		}
		var n = Math.min(Math.max(parseInt(m[1], 10), 1), this.numPages);
		var el = this.pagesEl.querySelector('[data-page-number="' + n + '"]');
		if (el) {
			setTimeout(function () {
				el.scrollIntoView({ block: 'start' });
			}, 100);
		}
	};

	Reader.prototype.showError = function (detail) {
		this.stateEl.className = 'gvp-state gvp-state-error';
		var spinner = this.stateEl.querySelector('.gvp-spinner');
		if (spinner) {
			spinner.remove();
		}
		var text = this.stateEl.querySelector('span');
		if (text) {
			text.textContent = 'We couldn’t load this publication.';
		}
		var detailEl = document.createElement('span');
		detailEl.className = 'gvp-state-detail';
		detailEl.textContent = detail;
		this.stateEl.appendChild(detailEl);
	};
})();
