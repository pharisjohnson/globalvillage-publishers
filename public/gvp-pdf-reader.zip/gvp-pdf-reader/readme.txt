=== GVP Read-Only PDF Reader ===
Contributors: globalvillagepublishers
Tags: pdf, reader, viewer, flipbook, magazine, read-only
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embeds a continuous-scroll, read-only PDF reader. Pages render to canvas so the
document is read on-screen and cannot be downloaded from the page.

== Description ==

GVP Read-Only PDF Reader turns any PDF into an in-browser magazine that readers
scroll through as one continuous page — with no download button, right-click or
drag-to-save. It uses Mozilla's PDF.js (loaded from the jsDelivr CDN) to draw
each page onto a canvas.

Features:

* Continuous scroll — pages flow together with no gaps, mixing portrait pages
  and landscape spreads seamlessly.
* Lazy rendering — pages draw as they enter the viewport, so long documents
  stay fast.
* Read-only — canvas rendering with right-click and drag-to-save disabled
  (best-effort: see the caveat below).
* Selectable text — on PDFs that contain a text layer.
* Share a page — WhatsApp, Facebook, X (Twitter) and copy-link buttons, with a
  deep link to the current page and any selected text included.
* Back-to-top button for long documents.
* Zero configuration — just drop in a shortcode.

== Installation ==

1. Copy the `gvp-pdf-reader` folder into `wp-content/plugins/`.
2. Activate the plugin in WordPress under Plugins.
3. Add a shortcode to any post or page.

== Usage ==

Basic usage with a PDF URL:

    [gvp-reader src="https://example.com/magazine.pdf"]

From the WordPress Media Library (preferred — upload the PDF to Media first):

    [gvp-reader id="123"]

With a title and all options:

    [gvp-reader id="123" title="Teachers' Image Vol 36" share="1" top="1"]

Shortcode attributes:

* `src`   (string) Absolute http(s) URL of the PDF.
* `id`    (int)    Media Library attachment ID; used when `src` is empty.
* `title` (string) Text shown in the reader toolbar. Default: "Publication".
* `share` (1/0)    Show the share button. Default 1.
* `top`   (1/0)    Show the back-to-top button. Default 1.

== Important caveat ==

The viewer is read-only by design (no download control, right-click and
drag-to-save disabled, pages drawn to canvas), but this is best-effort on the
open web: the PDF's own URL can still be fetched directly. To genuinely prevent
redistribution, protect the file at the server level (for example, by serving
it from a private origin with signed URLs or access controls). This plugin
removes the easy, obvious ways to save the file from the reading page.

The PDF must be reachable from the reader's browser. If you host the PDF on a
different domain, that host must allow cross-origin requests (CORS); serving
the PDF from your own WordPress Media Library always works.

== Changelog ==

= 1.0.0 =
* Initial release.
