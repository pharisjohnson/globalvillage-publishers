<?php
/**
 * Plugin Name:       GVP Read-Only PDF Reader
 * Plugin URI:        https://www.globalvillagepublishers.co.ke/
 * Description:       Embeds a continuous-scroll, read-only PDF viewer. Pages are rendered to <canvas> so the document is read on-screen and cannot be downloaded from the page. Usage: [gvp-reader src="https://example.com/file.pdf" title="..."] or [gvp-reader id="123"].
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Global Village Publishers
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       gvp-pdf-reader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GVP_PDF_Reader {

	/**
	 * PDF.js build the viewer loads from the jsDelivr CDN.
	 * Keep in sync with the version referenced in assets/gvp-reader.js.
	 */
	const PDFJS_VERSION = '6.5.438';

	/**
	 * Shortcode output counter, used to give each reader a stable id.
	 *
	 * @var int
	 */
	private static $counter = 0;

	public function __construct() {
		add_shortcode( 'gvp-reader', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
	}

	/**
	 * Register the script and enqueue the stylesheet.
	 *
	 * The stylesheet is enqueued on every page so it is present in <head> and
	 * avoids a flash of unstyled content (it is tiny and fully scoped under
	 * `.gvp-reader`). The script is only registered here and enqueued by the
	 * shortcode, in the footer; it is a no-op when no reader is present and
	 * loads PDF.js itself lazily from the CDN.
	 */
	public function register_assets() {
		wp_enqueue_style(
			'gvp-reader',
			plugin_dir_url( __FILE__ ) . 'assets/gvp-reader.css',
			array(),
			self::PDFJS_VERSION
		);

		wp_register_script(
			'gvp-reader',
			plugin_dir_url( __FILE__ ) . 'assets/gvp-reader.js',
			array(),
			self::PDFJS_VERSION,
			true
		);
	}

	/**
	 * Render the [gvp-reader] shortcode.
	 *
	 * Attributes:
	 *   src   string  Absolute http(s) URL of the PDF.
	 *   id    int     WordPress media attachment ID (used if `src` is empty).
	 *   title string  Toolbar title. Defaults to "Publication".
	 *   share bool    Show the share button (1/0). Default 1.
	 *   top   bool    Show the back-to-top button (1/0). Default 1.
	 */
	public function render_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'src'   => '',
				'id'    => 0,
				'title' => '',
				'share' => '1',
				'top'   => '1',
			),
			$atts,
			'gvp-reader'
		);

		$src = '';

		if ( ! empty( $atts['id'] ) ) {
			$attachment_id = absint( $atts['id'] );
			$url           = wp_get_attachment_url( $attachment_id );
			$mime          = get_post_mime_type( $attachment_id );
			if ( $url && 'application/pdf' === $mime ) {
				$src = $url;
			}
		}

		if ( ! $src && ! empty( $atts['src'] ) ) {
			$src = esc_url_raw( trim( $atts['src'] ), array( 'http', 'https' ) );
		}

		if ( ! $src ) {
			return '';
		}

		$title = sanitize_text_field( $atts['title'] );
		$share = $this->is_truthy( $atts['share'] ) ? 1 : 0;
		$top   = $this->is_truthy( $atts['top'] ) ? 1 : 0;

		wp_enqueue_script( 'gvp-reader' );

		self::$counter++;
		$id = 'gvp-reader-' . self::$counter;

		$config = array(
			'src'   => $src,
			'title' => $title,
			'share' => $share,
			'top'   => $top,
		);

		return sprintf(
			'<div class="gvp-reader" id="%1$s" data-config="%2$s"></div>',
			esc_attr( $id ),
			esc_attr( wp_json_encode( $config ) )
		);
	}

	/**
	 * Accept a loose set of boolean-ish strings.
	 *
	 * @param mixed $value
	 * @return bool
	 */
	private function is_truthy( $value ) {
		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes', 'on' ), true );
	}
}

new GVP_PDF_Reader();
